# This file was automatically created by FeynRules 2.3.49
# Mathematica version: 8.0 for Linux x86 (64-bit) (October 10, 2011)
# Date: Wed 28 Aug 2024 09:04:05


from object_library import all_couplings, Coupling

from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot



